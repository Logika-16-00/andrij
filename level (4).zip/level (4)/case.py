import pandas as pd

# Завантаження даних
df = pd.read_csv('DataAnalyst.csv')

# Фільтрація зарплат — виділення мінімальної та максимальної оцінки
df = df[df['Salary Estimate'].str.contains('\$') & ~df['Salary Estimate'].str.contains('Employer Provided')]

def parse_salary(salary_str):
    # Вилучення чисел і переведення в тисячі
    salary_str = salary_str.split('(')[0].replace('$', '').replace('K', '').replace(' ', '').split('-')
    if len(salary_str) == 2:
        min_salary = int(salary_str[0])
        max_salary = int(salary_str[1])
        avg_salary = (min_salary + max_salary) / 2
        return pd.Series([min_salary, max_salary, avg_salary])
    return pd.Series([None, None, None])

df[['Min Salary', 'Max Salary', 'Avg Salary']] = df['Salary Estimate'].apply(parse_salary)

# Кореляція між зарплатою та рейтингом компанії
correlation = df[['Avg Salary', 'Rating']].corr()

# Вивід середніх зарплат за сектором
avg_salary_by_sector = df.groupby('Sector')['Avg Salary'].mean().sort_values(ascending=False)

# Результати
print("Кореляція між середньою зарплатою та рейтингом компанії:")
print(correlation)

print("\nСередня зарплата по секторах:")
print(avg_salary_by_sector)